package Bai1;

import java.util.Stack;

public class Main {
    int x = 9;
    int y = 15;
    int z = 2;

}
